from flask_frozen import Freezer
from Jalapeno import app
#init Freezer
freezer = Freezer(app)