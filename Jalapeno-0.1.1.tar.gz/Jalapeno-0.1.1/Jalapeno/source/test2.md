title: this is just testing page
date: 2017-01-01 
tag: Flask

[TOC]

<!--Sidebar-->

##目录Table of content

将\[TOC\]放入文中即可在文中该位置生成目录，如果[<\!--Sidebar-->]()出现在\[TOC\]后，将使该目录移入到侧边栏

if [<\!--Sidebar-->]() shows after \[TOC\], the TOC part goes into sidebar


##引入图片格式(Image link)

Assume we have image file with path /source/image/test/testimg.img

![]({{image.test.testimg}})


<!--More-->

##摘要(exerpt)

The content Before [<\!--More-->]() will be load to posts excerpt

在[<\!--More-->]()之前的内容会被引入到文章列表摘要



##代码块格式(Code)

一个tab或4个空格(code block indentation: tab or 4 space)

	#!python
	def main()
		pass

##分割线如下

---

##表格(Table)

|函数|fib(5)|fib(4)|fib(3)|fib(2)|fib(1)|fib(0)|
|:-:|:--:|:--:|:--:|:--:|:--:|:--:|
|次数| 1  | 1  | 2  | 3  | 5  | 3(同2) |



This is just for test. Thank you for choosing Jalapeno.
